# Business Empire Simulator — Ultra Paper Market

A browser-only, single-player paper-trading simulator designed for free GitHub Pages hosting.

## Start

Open `index.html` in a modern browser. For local testing, run `python -m http.server 8080` in this folder and visit `http://localhost:8080`.

## Starting balance

- New games start with **$100 virtual cash**.
- Fractional units are supported, so small balances can buy fractional shares/ETF units.
- Market orders use a simulated bid/ask spread and a 0.10% simulated commission.
- Buy/sell orders are rejected while the selected exchange is closed.

## Market directory

The starter directory contains a broad selection of large-cap US, Singapore, Hong Kong, Japanese, UK, European and Australian equities; major ETFs; indices; major FX pairs; and large cryptocurrencies. It is not a complete list of every security in the world. The directory can be searched and filtered by instrument type and exchange.

## Market sessions

The simulator checks approximate regular weekday sessions using each exchange's timezone. Crypto is open 24/7; FX is modelled as a 24/5 market. Regular sessions are simplified and do not include the complete holiday calendar, early closes, auctions, halts, or every product-specific session. The simulator pauses price movement and blocks orders for closed instruments.

## Important data limitation

All prices, price changes, charts, volume, fills, spreads, fees, and market activity are **simulated**. Starting prices are illustrative reference values, not live quotes. There is no connection to an exchange, broker, market-data provider, or real-money account. Real-time quotes would require an external market-data API, licensing/redistribution rights, and usually a backend or API proxy; do not expose private API keys in a public GitHub Pages repository.

## Saving

Progress is saved in the current browser using `localStorage`. It does not sync between devices. Clearing browser storage can erase progress. The new ultra version uses its own save key and starts a fresh $100 game.

## GitHub Pages

Upload `index.html` and `README.md` to the root of a GitHub repository, then enable Pages under **Settings → Pages** using the `main` branch and root folder.
